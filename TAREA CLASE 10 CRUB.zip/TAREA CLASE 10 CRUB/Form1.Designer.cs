﻿namespace WinFormsApp2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            Carnet = new TextBox();
            Buscar = new Button();
            textBoxNombre = new TextBox();
            textBoxSeccion = new TextBox();
            textBoxNota1 = new TextBox();
            textBoxNota2 = new TextBox();
            textBoxNota3 = new TextBox();
            textBoxNota4 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            CrearNuevoRegistro = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // Carnet
            // 
            Carnet.BackColor = SystemColors.ActiveCaption;
            Carnet.Location = new Point(158, 40);
            Carnet.Margin = new Padding(3, 4, 3, 4);
            Carnet.Name = "Carnet";
            Carnet.Size = new Size(188, 27);
            Carnet.TabIndex = 0;
            Carnet.TextAlign = HorizontalAlignment.Center;
            Carnet.TextChanged += Carnet_TextChanged;
            // 
            // Buscar
            // 
            Buscar.BackColor = SystemColors.MenuHighlight;
            Buscar.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Buscar.Location = new Point(385, 40);
            Buscar.Margin = new Padding(3, 4, 3, 4);
            Buscar.Name = "Buscar";
            Buscar.Size = new Size(104, 42);
            Buscar.TabIndex = 1;
            Buscar.Text = "BUSCAR";
            Buscar.UseVisualStyleBackColor = false;
            Buscar.Click += Buscar_Click;
            // 
            // textBoxNombre
            // 
            textBoxNombre.BackColor = SystemColors.Info;
            textBoxNombre.Location = new Point(181, 138);
            textBoxNombre.Margin = new Padding(3, 4, 3, 4);
            textBoxNombre.Name = "textBoxNombre";
            textBoxNombre.Size = new Size(279, 27);
            textBoxNombre.TabIndex = 2;
            textBoxNombre.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxSeccion
            // 
            textBoxSeccion.BackColor = SystemColors.Info;
            textBoxSeccion.Location = new Point(181, 215);
            textBoxSeccion.Margin = new Padding(3, 4, 3, 4);
            textBoxSeccion.Name = "textBoxSeccion";
            textBoxSeccion.Size = new Size(102, 27);
            textBoxSeccion.TabIndex = 3;
            textBoxSeccion.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxNota1
            // 
            textBoxNota1.BackColor = Color.Azure;
            textBoxNota1.Location = new Point(147, 311);
            textBoxNota1.Margin = new Padding(3, 4, 3, 4);
            textBoxNota1.Name = "textBoxNota1";
            textBoxNota1.Size = new Size(50, 27);
            textBoxNota1.TabIndex = 4;
            textBoxNota1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxNota2
            // 
            textBoxNota2.BackColor = Color.Azure;
            textBoxNota2.Location = new Point(295, 311);
            textBoxNota2.Margin = new Padding(3, 4, 3, 4);
            textBoxNota2.Name = "textBoxNota2";
            textBoxNota2.Size = new Size(51, 27);
            textBoxNota2.TabIndex = 5;
            textBoxNota2.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxNota3
            // 
            textBoxNota3.Location = new Point(158, 368);
            textBoxNota3.Margin = new Padding(3, 4, 3, 4);
            textBoxNota3.Name = "textBoxNota3";
            textBoxNota3.Size = new Size(55, 27);
            textBoxNota3.TabIndex = 6;
            textBoxNota3.TextAlign = HorizontalAlignment.Center;
            // 
            // textBoxNota4
            // 
            textBoxNota4.Location = new Point(317, 368);
            textBoxNota4.Margin = new Padding(3, 4, 3, 4);
            textBoxNota4.Name = "textBoxNota4";
            textBoxNota4.Size = new Size(55, 27);
            textBoxNota4.TabIndex = 7;
            textBoxNota4.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(89, 40);
            label1.Name = "label1";
            label1.Size = new Size(62, 20);
            label1.TabIndex = 8;
            label1.Text = "Carnet: \r\n";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(89, 138);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 9;
            label2.Text = "Nombre:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(95, 215);
            label3.Name = "label3";
            label3.Size = new Size(65, 20);
            label3.TabIndex = 10;
            label3.Text = "Seccion:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(90, 315);
            label4.Name = "label4";
            label4.Size = new Size(57, 20);
            label4.TabIndex = 11;
            label4.Text = "Nota 1:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(235, 315);
            label5.Name = "label5";
            label5.Size = new Size(59, 20);
            label5.TabIndex = 12;
            label5.Text = "Nota 2:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(88, 371);
            label6.Name = "label6";
            label6.Size = new Size(59, 20);
            label6.TabIndex = 13;
            label6.Text = "Nota 3:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(251, 371);
            label7.Name = "label7";
            label7.Size = new Size(60, 20);
            label7.TabIndex = 14;
            label7.Text = "Nota 4:";
            // 
            // CrearNuevoRegistro
            // 
            CrearNuevoRegistro.BackColor = SystemColors.ControlDark;
            CrearNuevoRegistro.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CrearNuevoRegistro.Location = new Point(215, 446);
            CrearNuevoRegistro.Margin = new Padding(3, 4, 3, 4);
            CrearNuevoRegistro.Name = "CrearNuevoRegistro";
            CrearNuevoRegistro.Size = new Size(79, 37);
            CrearNuevoRegistro.TabIndex = 15;
            CrearNuevoRegistro.Text = "Crear";
            CrearNuevoRegistro.UseVisualStyleBackColor = false;
            CrearNuevoRegistro.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Red;
            button3.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(325, 446);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(103, 37);
            button3.TabIndex = 17;
            button3.Text = "Eliminar";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(677, 566);
            Controls.Add(button3);
            Controls.Add(CrearNuevoRegistro);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxNota4);
            Controls.Add(textBoxNota3);
            Controls.Add(textBoxNota2);
            Controls.Add(textBoxNota1);
            Controls.Add(textBoxSeccion);
            Controls.Add(textBoxNombre);
            Controls.Add(Buscar);
            Controls.Add(Carnet);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "UMG";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox Carnet;
        private Button Buscar;
        private TextBox textBoxNombre;
        private TextBox textBoxSeccion;
        private TextBox textBoxNota1;
        private TextBox textBoxNota2;
        private TextBox textBoxNota3;
        private TextBox textBoxNota4;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button CrearNuevoRegistro;
        private Button button3;
    }
}
